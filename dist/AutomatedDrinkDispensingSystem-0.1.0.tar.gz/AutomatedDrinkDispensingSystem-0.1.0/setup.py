#!/usr/bin/env python3

from distutils.core import setup

setup(
    name="AutomatedDrinkDispensingSystem",
    version="0.1.0",
    author="Chris B.",
    author_email="christopherablanks@gmail.com",
    packages=["automated-self-serving-system",],
    license="LICENSE.txt",
    long_description=open("README.txt").read(),
    install_requires=[
        "cryptography >= 1.7.1",
    ],
)
